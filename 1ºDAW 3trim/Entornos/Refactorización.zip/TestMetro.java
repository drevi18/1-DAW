public class TestMetro {
    public static void main(String []args)
    {
    Metro m = new Metro();
    System.out.println("Estado = " + m.print());
    m.cambiaEstado();
    System.out.println("Estado = " + m.print());
    m.cambiaEstado();
    System.out.println("Estado = " + m.print());
    m.cambiaEstado();
    System.out.println("Estado = " + m.print());
    m.cambiaEstado();
    System.out.println("Estado = " + m.print());
    }
   } 
