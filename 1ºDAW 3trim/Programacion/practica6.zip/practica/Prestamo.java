
import java.util.Date;

public class Prestamo {
    private Integer cod_pres;
    private Socio socio;
    private Copia copia;
    private Date fech_pres;
    private Date fech_dev;

}
