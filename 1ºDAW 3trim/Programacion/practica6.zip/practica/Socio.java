
public class Socio {
    private String nombre;
    private Integer num;

    public Socio(){
        nombre=" ";
        num=null;
    }

    
    public Socio(String nombre, int num){
        this.nombre=nombre;
        this.num=num;
    }
}
