package Practicas.tarea1;

public interface Interfaz {
    public static double iva=0;

    @Override
    public String toString();
}
