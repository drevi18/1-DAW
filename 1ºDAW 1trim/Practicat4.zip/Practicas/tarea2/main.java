package Practicas.tarea2;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner tec= new Scanner(System.in);

        System.out.println("Introduce el primer número");
        int num1= tec.nextInt();
        System.out.println("Introduce el segundo número");
        int num2= tec.nextInt();
        
    }
}
