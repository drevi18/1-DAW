package Practicas.tarea2;

public abstract  class division {
    
}
