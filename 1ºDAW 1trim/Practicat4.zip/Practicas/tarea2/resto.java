package Practicas.tarea2;

public class resto {
    
}
